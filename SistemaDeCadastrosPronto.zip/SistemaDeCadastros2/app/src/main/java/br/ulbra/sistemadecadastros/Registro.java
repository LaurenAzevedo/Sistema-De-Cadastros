package br.ulbra.sistemadecadastros;

public class Registro {
    // classe de metodos
    private String nome;
    private String endereco;
    private String telefone;

    //criando metodo construtor = carreganto todos os valores de forma mais facil
    public Registro (String nome, String endereco, String telefone){
        this.nome = nome; //this = jogando os valores para dentro do metodo
        this.endereco = endereco;
        this.telefone = telefone;
    }
    //criando metodos getter  //encapsulamento = acessar de qualquer lugar do codigo
    public String getNome(){
        return nome;
    }
    //get ta pegando a informação la dentro e em um determinado mopmento vai retornar
    public String getEndereco (){
        return endereco;
    }
    public String getTelefone () {
        return telefone;
    }
}

